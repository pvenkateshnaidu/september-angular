(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["common"],{

/***/ "./node_modules/primeng/confirmdialog.js":
/*!***********************************************!*\
  !*** ./node_modules/primeng/confirmdialog.js ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* Shorthand */

function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
Object.defineProperty(exports, "__esModule", { value: true });
__export(__webpack_require__(/*! ./components/confirmdialog/confirmdialog */ "./node_modules/primeng/components/confirmdialog/confirmdialog.js"));

/***/ })

}]);
//# sourceMappingURL=common-es5.js.map